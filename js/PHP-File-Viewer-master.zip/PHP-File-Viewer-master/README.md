#PHP File Viewer

##About
* Http File Viewer using PHP Language.
* Support mobile environments.

##Dependaries
All of libraries is included in `main-browser-library`. used libraries is below.
* jQuery 2.1.1 `./main-browser-library/jquery`
* Bootstrap 3.1.1 `./main-browser-library/bootstrap-3.1-2.1`

##SetUp
* Upload all of this `repo.` to your server directory that you want to apply File Viewer.

##Sample
* http://moblab.co.kr/seminar
